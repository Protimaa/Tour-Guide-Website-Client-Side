/**
 * 1. do not show the link to those user who should not see the link
 * 2. even if they gets the link, do not allow them to visit the link
 * 3. do not allow user to access the api. check admin in the server as well
 * (verifyAdmin)
*/