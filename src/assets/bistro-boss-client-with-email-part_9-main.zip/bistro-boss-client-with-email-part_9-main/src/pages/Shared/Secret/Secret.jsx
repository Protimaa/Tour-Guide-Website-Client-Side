
const Secret = () => {
    return (
        <div>
            <h2>Secret things</h2>
        </div>
    );
};

export default Secret;